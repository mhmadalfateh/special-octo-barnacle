package com.mohammedalfateh.mustawda

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.FrameLayout
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient

class MainActivity : Activity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Decorative native outer frame only. The original HTML and its contents remain unchanged.
        val outerFrame = FrameLayout(this).apply {
            setBackgroundColor(Color.rgb(3, 23, 19))
            setPadding(dp(5), dp(5), dp(5), dp(5))
        }
        val frameBorder = GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            setColor(Color.rgb(3, 23, 19))
            setStroke(dp(3), Color.rgb(214, 167, 43))
            cornerRadius = dp(22).toFloat()
        }
        outerFrame.background = frameBorder

        webView = WebView(this)
        webView.setBackgroundColor(Color.rgb(0, 11, 9))
        val webParams = FrameLayout.LayoutParams(
            FrameLayout.LayoutParams.MATCH_PARENT,
            FrameLayout.LayoutParams.MATCH_PARENT
        ).apply {
            setMargins(dp(3), dp(3), dp(3), dp(3))
            gravity = Gravity.CENTER
        }
        outerFrame.addView(webView, webParams)
        setContentView(outerFrame)

        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.settings.databaseEnabled = true
        webView.settings.javaScriptCanOpenWindowsAutomatically = true
        webView.settings.setSupportMultipleWindows(false)
        webView.settings.cacheMode = WebSettings.LOAD_DEFAULT
        webView.webChromeClient = WebChromeClient()

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val url = request.url
                val scheme = url.scheme ?: ""
                if (scheme == "http" || scheme == "https" || scheme == "whatsapp" || scheme == "tg") {
                    if (url.host == "wa.me" || url.host == "api.whatsapp.com" ||
                        url.host == "t.me" || scheme == "whatsapp" || scheme == "tg") {
                        return openExternal(url)
                    }
                    if (url.host != null && !url.host!!.contains("jsdelivr.net")) {
                        return openExternal(url)
                    }
                }
                return false
            }

            @Suppress("DEPRECATION")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                val uri = Uri.parse(url)
                if (uri.scheme == "http" || uri.scheme == "https" ||
                    uri.scheme == "whatsapp" || uri.scheme == "tg") {
                    if (uri.host == "wa.me" || uri.host == "api.whatsapp.com" ||
                        uri.host == "t.me" || uri.scheme == "whatsapp" || uri.scheme == "tg") {
                        return openExternal(uri)
                    }
                }
                return false
            }
        }

        if (savedInstanceState == null) {
            webView.loadUrl("file:///android_asset/index.html")
        } else {
            webView.restoreState(savedInstanceState)
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density + 0.5f).toInt()

    private fun openExternal(uri: Uri): Boolean {
        return try {
            val intent = Intent(Intent.ACTION_VIEW, uri)
            startActivity(intent)
            true
        } catch (_: Exception) {
            false
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        webView.saveState(outState)
        super.onSaveInstanceState(outState)
    }

    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    override fun onDestroy() {
        webView.destroy()
        super.onDestroy()
    }
}
